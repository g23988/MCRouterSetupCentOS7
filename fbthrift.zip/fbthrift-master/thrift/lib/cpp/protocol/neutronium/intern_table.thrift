namespace cpp apache.thrift.protocol.neutronium

struct InternTableSizes {
  1: required list<i32> sizes,
}

