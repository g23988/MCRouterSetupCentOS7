struct Point {
  1: i32 x;
  2: i32 y;
}

struct Path1 {
  1: list<Point> points;
}

struct Path2 {
  1: list<i32> xs;
  2: list<i32> ys;
}
