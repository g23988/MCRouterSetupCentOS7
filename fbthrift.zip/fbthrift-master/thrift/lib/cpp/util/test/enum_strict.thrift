enum EnumStrict {
  UNKNOWN = 0,
  VALUE = 1,
  FOO = 2,
  BAR = 3,
}
