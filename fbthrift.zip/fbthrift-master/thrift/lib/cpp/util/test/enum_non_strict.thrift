enum EnumNonStrict {
  UNKNOWN = 0,
  VALUE = 1,
  FOO = 2,
  BAR = 3,
  // DEPRECATED = 4,
  NEW_VALUE = 6,
}
